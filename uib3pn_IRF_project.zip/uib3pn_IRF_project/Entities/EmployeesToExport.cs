﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uib3pn_IRF_project.Entities
{
    public class EmployeesToExport:Employee
    {
        public string phone { get; set; }
        public string gender { get; set; }
        
    }
}
