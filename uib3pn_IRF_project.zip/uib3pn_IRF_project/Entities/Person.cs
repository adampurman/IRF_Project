﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uib3pn_IRF_project.Entities
{
    class Person

    {
        public head CreateNew(){
            return new head();
            
        }
    
    }
}
